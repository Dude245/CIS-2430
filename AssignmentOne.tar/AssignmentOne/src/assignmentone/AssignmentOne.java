package assignmentone;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * @author Nathan Reymer
 */
public class AssignmentOne {
    public static void main(String[] args) {
        int Stop = 1;
        int Lnum = 0;
        String input;
        String Search;
        String[] List = new String[500];
        System.out.println("Welcome to the Library Search Program");
        while (Stop == 1) {
            if (Lnum > 450) {
                System.out.println("There is a 500 array limit! You are at: " + Lnum);
            }
            System.out.println("Please choose from one of the following options");
            System.out.println("1. Add");
            System.out.println("2. Search");
            System.out.println("3. Display Array");
            System.out.println("4. Quit \n");
            Scanner in = new Scanner(System.in);
            String choice = in.nextLine();
            switch (choice) {
                case "1": {
                    System.out.print("Add: ");
                    input = in.nextLine();
                    input = input.replace(":"," ");
                    input = input.replace("."," ");
                    input = input.replace(";",",");
                    List[Lnum] = (input);
                    // Duplication Check
                    for (int Check = 0; Check < Lnum; Check++) {
                        boolean equals = input.equalsIgnoreCase(List[Check]);
                        if (equals == true) {
                            System.out.println("Duplicate Entry!");
                            Lnum--;
                        }
                    }
                    Lnum++;
                    break;
                }
                case "2": {
                    System.out.print("Search: ");
                    Search = in.nextLine();
                    System.out.println();
                    LibrarySearch(Search, List, Lnum);
                    break;
                }
                case "3": {
                    System.out.println("Array:");
                    for (int count = 0; count < Lnum; count++) {
                        System.out.println(List[count]);
                    }
                    break;
                }
                case "4": {
                    System.out.println("Quit");
                    Stop = 0;
                    break;
                }
                default: {
                    System.out.println("Not a choice!");
                    break;
                }
            }
        }
    }

    public static void LibrarySearch(String search, String[] array, int Lnum) {
        String newArray;
        int None=0;
        search = ("(?i).*" + search + ".*");
        String patternString = (search);
        Pattern pattern = Pattern.compile(patternString);
        for (int x = 0; x < Lnum; x++) {
            newArray = array[x];
            Matcher matcher = pattern.matcher(newArray);
            boolean matches = matcher.matches();
            if (matches == true) {
                System.out.println("Found: " + newArray);
                None++;
            }
        }
        if(None==0)
        {
            System.out.println("Sorry, I could't find any results!");
        }
        System.out.println();
    }
}
