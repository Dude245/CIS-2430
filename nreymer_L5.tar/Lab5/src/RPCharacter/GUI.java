/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RPCharacter;

import javax.swing.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import utils.Die;
import utils.FileIO;

/**
 *
 * @author Nathan
 */
public class GUI extends JFrame implements ActionListener {

    public static ArrayList<RPCharacter> characterList = new ArrayList<>();
    static String CHARACTER_FILE_PATH = "./data/rpdata.save";
    ArrayList<HashMap<String, String>> characterHashList;

    private final JMenuItem create = new JMenuItem("Create");
    private final JMenuItem edit = new JMenuItem("Edit");
    private final JMenuItem enc = new JMenuItem("Enhance");
    private final JMenuItem sExit = new JMenuItem("Save and Exit");
    private final JMenuItem exit = new JMenuItem("Exit");
    private final JButton nextChar = new JButton("Next Character");
    private final JButton accept = new JButton("Accept");
    private final JButton cancel = new JButton("Cancel");
    private final JButton rollAgain = new JButton("Roll");
    int currentC = 0;
    boolean clicked = false;
    boolean editable = false;
    boolean createAble = false;

    JFrame frame = new JFrame("RPCharacter Manager");
    JLabel fNameLabel = new JLabel("First Name");
    JTextField fName = new JTextField();
    JLabel lNameLabel = new JLabel("Last Name");
    JTextField lName = new JTextField();
    JLabel ageLabel = new JLabel("Age");
    JTextField age = new JTextField();
    JLabel classLabel = new JLabel("Class");
    JTextField cClass = new JTextField();
    JMenuBar menuBar = new JMenuBar();
    JMenu menu = new JMenu("File");

    JLabel strLbl = new JLabel("Strength");
    JTextField str = new JTextField();
    JLabel dexLbl = new JLabel("Dexterity");
    JTextField dex = new JTextField();
    JLabel conLbl = new JLabel("Constituton");
    JTextField con = new JTextField();
    JLabel intLbl = new JLabel("Intelligence");
    JTextField intT = new JTextField();
    JLabel wisLbl = new JLabel("Wisdom");
    JTextField wis = new JTextField();
    JLabel chaLbl = new JLabel("Charisma");
    JTextField cha = new JTextField();
    JLabel lvlLbl = new JLabel("Level");
    JTextField lvl = new JTextField();
    JLabel spLbl = new JLabel("Speed");
    JTextField sp = new JTextField();

    String Classes[] = {"Wizard", "Bard", "Fighter"};
    JComboBox classChoose = new JComboBox(Classes);
    JButton search = new JButton("Search");
    int cFlag = 0;

    public GUI() throws InterruptedException {
        characterHashList = FileIO.readDataFromFile(CHARACTER_FILE_PATH);
        characterList = RPCharacter.convertHashMapListToCharacterList(characterHashList);
        revalidate();
        repaint();
        //Create the menu bar.

        menuBar.add(menu);
        frame.setJMenuBar(menuBar);
        create.addActionListener(this);
        edit.addActionListener(this);
        sExit.addActionListener(this);
        exit.addActionListener(this);
        enc.addActionListener(this);
        nextChar.addActionListener(this);
        accept.addActionListener(this);
        cancel.addActionListener(this);
        classChoose.addActionListener(this);
        search.addActionListener(this);
        rollAgain.addActionListener(this);

        classChoose.setSelectedIndex(0);

        frame.setLayout(null);
        menu.add(create);
        menu.add(edit);
        menu.add(enc);
        menu.add(sExit);
        menu.add(exit);
        frame.setBackground(Color.white);
        frame.setSize(400, 500);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        nextChar.setBounds(200, 350, 120, 40);
        accept.setBounds(80, 350, 120, 40);
        accept.setVisible(false);
        cancel.setVisible(false);
        cancel.setBounds(220, 350, 120, 40);
        frame.add(accept);
        frame.add(cancel);
        frame.add(nextChar);

        frame.setVisible(true);
        fNameLabel.setBounds(20, 20, 100, 40);
        fName.setBounds(120, 20, 100, 40);
        lNameLabel.setBounds(20, 80, 100, 40);
        lName.setBounds(120, 80, 100, 40);
        ageLabel.setBounds(20, 110, 100, 100);
        age.setBounds(120, 140, 100, 40);
        classLabel.setBounds(20, 170, 100, 100);
        cClass.setBounds(121, 200, 100, 40);
        classChoose.setBounds(120, 200, 100, 40);
        search.setBounds(0, 350, 120, 40);
        search.setVisible(true);
        frame.add(search);

        strLbl.setBounds(240, 20, 100, 40);
        frame.add(strLbl);
        str.setBounds(310, 20, 40, 30);
        frame.add(str);
        dexLbl.setBounds(240, 60, 100, 40);
        frame.add(dexLbl);
        dex.setBounds(310, 60, 40, 30);
        frame.add(dex);
        conLbl.setBounds(240, 100, 100, 40);
        frame.add(conLbl);
        con.setBounds(310, 100, 40, 30);
        frame.add(con);
        intLbl.setBounds(240, 140, 100, 40);
        frame.add(intLbl);
        intT.setBounds(310, 140, 40, 30);
        frame.add(intT);
        wisLbl.setBounds(240, 180, 100, 40);
        frame.add(wisLbl);
        wis.setBounds(310, 180, 40, 30);
        frame.add(wis);
        chaLbl.setBounds(240, 220, 100, 40);
        frame.add(chaLbl);
        cha.setBounds(310, 220, 40, 30);
        frame.add(cha);
        lvlLbl.setBounds(240, 260, 100, 40);
        frame.add(lvlLbl);
        lvl.setBounds(310, 260, 40, 30);
        frame.add(lvl);
        spLbl.setBounds(240, 300, 100, 40);
        frame.add(spLbl);
        sp.setBounds(310, 300, 40, 30);
        frame.add(sp);
        rollAgain.setBounds(140, 260, 60, 20);
        frame.add(rollAgain);
        rollAgain.setVisible(false);
        str.setEditable(editable);
        dex.setEditable(editable);
        con.setEditable(editable);
        intT.setEditable(editable);
        wis.setEditable(editable);
        cha.setEditable(editable);
        lvl.setEditable(editable);
        sp.setEditable(editable);

        frame.add(fNameLabel);

        frame.add(fNameLabel);
        fName.setEditable(editable);
        frame.add(fName);

        frame.add(lNameLabel);
        lName.setEditable(editable);
        frame.add(lName);

        frame.add(ageLabel);
        age.setEditable(editable);
        frame.add(age);

        frame.add(classLabel);
        frame.add(classChoose);
        frame.add(cClass);
        cClass.setEditable(editable);
        cClass.setVisible(true);
        classChoose.setVisible(false);

        revalidate();
        repaint();

    }

    @Override
    public void actionPerformed(ActionEvent E) {
        if (E.getSource() == exit) {
            System.exit(0);
        } else if (E.getSource() == sExit) {
            FileIO.printMe(RPCharacter.convertCharacterListToHashMapList(characterList), CHARACTER_FILE_PATH);
            System.exit(0);
        } else if (E.getSource() == enc) {
            editable = false;
            rollAgain.setVisible(true);
            nextChar.setVisible(false);
            accept.setVisible(true);
            cancel.setVisible(true);
            search.setVisible(false);
            str.setEditable(editable);
            dex.setEditable(editable);
            con.setEditable(editable);
            intT.setEditable(editable);
            wis.setEditable(editable);
            cha.setEditable(editable);
            lvl.setEditable(editable);
            sp.setEditable(editable);
        } else if (E.getSource() == rollAgain) {
            if (currentC - 1 == -1) {
                currentC = characterList.size();
            }
            Die test = new Die();
            int rollMe;
            fName.setText(characterList.get(currentC - 1).getFirstName());
            lName.setText(characterList.get(currentC - 1).getLastName());
            cClass.setText(characterList.get(currentC - 1).getCharacterClass());
            age.setText(String.valueOf(characterList.get(currentC - 1).getAge()));
            rollMe = test.generateAbilityScoreStandard();
            str.setText(String.valueOf(rollMe));
            rollMe = test.generateAbilityScoreStandard();
            dex.setText(String.valueOf(rollMe));
            rollMe = test.generateAbilityScoreStandard();
            con.setText(String.valueOf(rollMe));
            rollMe = test.generateAbilityScoreStandard();
            intT.setText(String.valueOf(rollMe));
            rollMe = test.generateAbilityScoreStandard();
            wis.setText(String.valueOf(rollMe));
            rollMe = test.generateAbilityScoreStandard();
            cha.setText(String.valueOf(rollMe));
            rollMe = test.generateAbilityScoreStandard();
            lvl.setText(String.valueOf(rollMe * 2));
            rollMe = test.generateAbilityScoreStandard();
            sp.setText(String.valueOf(rollMe * 3));
            cFlag = 3;

        } else if (E.getSource() == search) {
            accept.setVisible(true);
            cancel.setVisible(true);
            search.setVisible(false);
            nextChar.setVisible(false);
            fName.setEditable(true);
            lName.setEditable(true);
            fName.setText("");
            lName.setText("");
            cClass.setText("");
            age.setText("");
            str.setText("");
            dex.setText("");
            con.setText("");
            intT.setText("");
            wis.setText("");
            cha.setText("");
            lvl.setText("");
            sp.setText("");
            cFlag = 4;
        } else if (E.getSource() == edit) {
            nextChar.setVisible(false);
            accept.setVisible(true);
            cancel.setVisible(true);
            cClass.setVisible(true);
            search.setVisible(false);
            editable = true;
            clicked = true;
            fName.setEditable(editable);
            lName.setEditable(editable);
            age.setEditable(editable);
            cClass.setEditable(false);
            editable = false;
            cFlag = 0;
        } else if (E.getSource() == accept) {
            try {
                if (cFlag == 4) {
                    String S1 = fName.getText();
                    String S2 = lName.getText();
                    int iAge = 1;

                    for (int i = 0; i < characterList.size(); i++) {
                        if (characterList.get(i).getFirstName().equalsIgnoreCase(S1)) {
                            currentC = i;
                            iAge = 2;
                            JOptionPane.showMessageDialog(frame, "Found");
                            fName.setText(characterList.get(currentC).getFirstName());
                            lName.setText(characterList.get(currentC).getLastName());
                            cClass.setText(characterList.get(currentC).getCharacterClass());
                            age.setText(String.valueOf(characterList.get(currentC).getAge()));
                            str.setText(String.valueOf(characterList.get(currentC).getStrength()));
                            dex.setText(String.valueOf(characterList.get(currentC).getDexterity()));
                            con.setText(String.valueOf(characterList.get(currentC).getConstitution()));
                            intT.setText(String.valueOf(characterList.get(currentC).getIntelligence()));
                            wis.setText(String.valueOf(characterList.get(currentC).getWisdom()));
                            cha.setText(String.valueOf(characterList.get(currentC).getCharisma()));
                            lvl.setText(String.valueOf(characterList.get(currentC).getLevel()));
                            sp.setText(String.valueOf(characterList.get(currentC).getSpeed()));
                        }
                        if (S2.equals("")) {
                            iAge = 3;
                        }
                        if (iAge != 3) {
                            if (characterList.get(i).getLastName().equalsIgnoreCase(S2)) {
                                currentC = i;
                                iAge = 2;
                            }
                        }
                    }
                }
                if (cFlag == 3) {
                    currentC--;

                    characterList.get(currentC).setFirstName(fName.getText());
                    characterList.get(currentC).setLastName(lName.getText());
                    characterList.get(currentC).setFirstName(age.getText());
                    characterList.get(currentC).setStrength(Integer.parseInt(str.getText()));
                    characterList.get(currentC).setDexterity(Integer.parseInt(dex.getText()));
                    characterList.get(currentC).setConstitution(Integer.parseInt(con.getText()));
                    characterList.get(currentC).setIntelligence(Integer.parseInt(intT.getText()));
                    characterList.get(currentC).setWisdom(Integer.parseInt(wis.getText()));
                    characterList.get(currentC).setCharisma(Integer.parseInt(cha.getText()));
                    characterList.get(currentC).setLevel(Integer.parseInt(lvl.getText()));
                    characterList.get(currentC).setSpeed(Float.parseFloat(sp.getText()));

                }
                if (cFlag == 0) {
                    try{
                    currentC--;
                    characterList.get(currentC).setFirstName(fName.getText());
                    characterList.get(currentC).setLastName(lName.getText());
                    characterList.get(currentC).setFirstName(age.getText());
                    characterList.get(currentC).setStrength(Integer.parseInt(str.getText()));
                    characterList.get(currentC).setDexterity(Integer.parseInt(dex.getText()));
                    characterList.get(currentC).setConstitution(Integer.parseInt(con.getText()));
                    characterList.get(currentC).setIntelligence(Integer.parseInt(intT.getText()));
                    characterList.get(currentC).setWisdom(Integer.parseInt(wis.getText()));
                    characterList.get(currentC).setCharisma(Integer.parseInt(cha.getText()));
                    characterList.get(currentC).setLevel(Integer.parseInt(lvl.getText()));
                    characterList.get(currentC).setSpeed(Float.parseFloat(sp.getText()));
                    }
                    catch(NumberFormatException t)
                    {
                        
                    }
                }
                if (cFlag == 1) {
                    Die test = new Die();
                    int rollMe;
                    RPCharacter newCharacter;
                    String value = classChoose.getSelectedItem().toString();
                    switch (value) {
                        case "Fighter":
                            newCharacter = new RPFighter("FIGHTER");
                            break;
                        case "Wizard":
                            newCharacter = new RPWizard("WIZARD");
                            break;
                        default:
                            newCharacter = new RPBard("BARD");
                            break;
                    }
                    if (fName.getText().equals("")) {
                        JOptionPane.showMessageDialog(frame, "You need to enter a First Name.");
                    }
                    if (lName.getText().equals("")) {
                        JOptionPane.showMessageDialog(frame, "You need to enter a Last Name.");
                    }
                    newCharacter.setFirstName(fName.getText());
                    newCharacter.setLastName(lName.getText());
                    newCharacter.setAge(Integer.parseInt(age.getText()));
                    characterList.add(newCharacter);
                    currentC = characterList.size() - 1;
                    rollMe = test.generateAbilityScoreStandard();
                    characterList.get(currentC).setCharisma(rollMe);
                    rollMe = test.generateAbilityScoreStandard();
                    characterList.get(currentC).setIntelligence(rollMe);
                    rollMe = test.generateAbilityScoreStandard();
                    characterList.get(currentC).setWisdom(rollMe);
                    rollMe = test.generateAbilityScoreStandard();
                    characterList.get(currentC).setDexterity(rollMe);
                    characterList.get(currentC).setConstitution(rollMe);
                    rollMe = test.generateAbilityScoreStandard();
                    characterList.get(currentC).setStrength(rollMe);
                    rollMe = test.generateAbilityScoreStandard();
                    characterList.get(currentC).setLevel(rollMe * 2);
                    rollMe = test.generateAbilityScoreStandard();
                    characterList.get(currentC).setSpeed(rollMe * 3);

                }
                accept.setVisible(false);
                cancel.setVisible(false);
                cClass.setVisible(true);
                classChoose.setVisible(false);
                nextChar.setVisible(true);
                editable = false;
                rollAgain.setVisible(false);
                fName.setEditable(editable);
                lName.setEditable(editable);
                age.setEditable(editable);
            } catch (NumberFormatException t) {
                JOptionPane.showMessageDialog(frame, "You need to enter a valid age");
            }
        } else if (E.getSource() == cancel) {
            accept.setVisible(false);
            cancel.setVisible(false);
            nextChar.setVisible(true);
            editable = false;
            fName.setEditable(editable);
            lName.setEditable(editable);
            age.setEditable(editable);
            cClass.setEditable(editable);
            cClass.setVisible(true);
            classChoose.setVisible(false);

        } else if (E.getSource() == create) {
            createAble = true;
            cClass.setVisible(false);
            nextChar.setVisible(false);
            classChoose.setVisible(true);
            accept.setVisible(true);
            cancel.setVisible(true);
            editable = true;
            fName.setEditable(editable);
            lName.setEditable(editable);
            age.setEditable(editable);
            fName.setText("");
            lName.setText("");
            age.setText("");
            cFlag = 1;

        } else if (E.getSource() == nextChar) {
            nextChar.setVisible(true);
            cClass.setVisible(true);
            cClass.setEditable(false);
            search.setVisible(true);
            fName.setText(characterList.get(currentC).getFirstName());
            lName.setText(characterList.get(currentC).getLastName());
            cClass.setText(characterList.get(currentC).getCharacterClass());
            age.setText(String.valueOf(characterList.get(currentC).getAge()));
            str.setText(String.valueOf(characterList.get(currentC).getStrength()));
            dex.setText(String.valueOf(characterList.get(currentC).getDexterity()));
            con.setText(String.valueOf(characterList.get(currentC).getConstitution()));
            intT.setText(String.valueOf(characterList.get(currentC).getIntelligence()));
            wis.setText(String.valueOf(characterList.get(currentC).getWisdom()));
            cha.setText(String.valueOf(characterList.get(currentC).getCharisma()));
            lvl.setText(String.valueOf(characterList.get(currentC).getLevel()));
            sp.setText(String.valueOf(characterList.get(currentC).getSpeed()));
            if (characterList.size() - 1 <= currentC) {
                currentC = 0;

            } else if (currentC < characterList.size()) {
                currentC++;
            }
        }

    }

}
