package RPCharacter;

/**
 * <p>
 * Character Manager that can be used in a role-playing game.</p>
 *
 * @author Nreymer/0797359
 */
public class RPCharacterManager {
    /**
     * Main PRogram
     *
     * @param args
     */
    public static void main(String[] args) throws InterruptedException {
        //Create and set up the content pane.
        new GUI();        
    }
}
