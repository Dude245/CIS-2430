To specify the input and output files of the program, run it with the input file as the first agrument, and the output file as the second argument.
The default save folder is /data/Database.txt